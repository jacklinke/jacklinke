/*
 Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("uicolor","ca",{title:"UI Color Picker",options:"Color Options",highlight:"Highlight",selected:"Selected Color",predefined:"Conjunts de colors predefinits",config:"Enganxa aquest text dins el fitxer config.js"});