# Home on the range with Django - getting comfortable with ranges and range fields

This presentation will be used for my talk on 2022-10-19 at [DjangoCon US 2022](https://2022.djangocon.us/).

You can view the presentation by either opening `index.html` in your web browser, or by viewing the included PDF document.

This presentation uses [reveal.js](https://revealjs.com/).